Rectangle: (LowerLeft, UpperRight)
External Jar: jts.jar
source files are in: cse512 folder

To run the whole project on spark, 
1. change the ipaddress in env.conf and set it as the master's ip address.
2. run ./run.sh
