Rectangle: (LowerLeft, UpperRight)
External Jar: jts.jar
